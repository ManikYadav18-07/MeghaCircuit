"""Renders photo-style PCB pictures into assets/img/. Used by build.py (needs Pillow + numpy)."""
import os,random,hashlib
import numpy as np
from functools import lru_cache
from PIL import Image,ImageDraw,ImageFilter,ImageFont
Z=2;CW,CH=2400,1600
GOLD=(214,176,62);SILV=(205,208,212);WH=(238,238,232);DIRS=[(1,0),(-1,0),(0,1),(0,-1)];PADS=True
PAL=[((18,140,80),(10,92,58)),((18,140,80),(10,92,58)),((40,100,190),(22,64,124)),((200,48,58),(140,30,40)),((46,52,60),(20,24,30))]
RULES=[('stencil',('stencil',)),('flex',('flex',)),('multi',('multilayer','multi-layer')),('single',('single',)),('chips',('sourcing','component')),('design',('layout','design')),('metal',('metal','lighting')),('panel',('fabricat','panel')),('stack',('product',)),('assembly',('assembl','smt','turnkey','manufactur'))]
Qd=[]
FORCE=[('slide-assembling',PAL[0]),('slide-fabrication',PAL[3])]
def name(k):return hashlib.sha1(k.encode()).hexdigest()[:10]+'.jpg'
@lru_cache(None)
def fnt(sz):
    for n in('DejaVuSansMono-Bold.ttf','DejaVuSans-Bold.ttf','LiberationMono-Bold.ttf'):
        try:return ImageFont.truetype(n,sz)
        except Exception:pass
    return ImageFont.load_default(sz)
def mix(a,b,t):return tuple(int(a[i]*(1-t)+b[i]*t) for i in range(3))
def grad(w,h,c1,c2,nz=3,seed=0):
    x=np.linspace(0,1,w)[None,:];y=np.linspace(0,1,h)[:,None];t=(x*.6+y*.4)[...,None]
    a=np.array(c1,float)*(1-t)+np.array(c2,float)*t+np.random.default_rng(seed).normal(0,nz,(h,w,1))
    return Image.fromarray(np.clip(a,0,255).astype('uint8'),'RGB')
class Dw:
    def __init__(s,im):s.im=im;s.d=ImageDraw.Draw(im)
    def r(s,x,y,w,h,f,rad=0,o=None,ow=1):s.d.rounded_rectangle([x*Z,y*Z,(x+w)*Z,(y+h)*Z],radius=rad*Z,fill=f,outline=o,width=max(1,int(ow*Z)))
    def c(s,x,y,r,f,o=None,ow=1):s.d.ellipse([(x-r)*Z,(y-r)*Z,(x+r)*Z,(y+r)*Z],fill=f,outline=o,width=max(1,int(ow*Z)))
    def l(s,pts,f,w):
        P=[(x*Z,y*Z) for x,y in pts];s.d.line(P,fill=f,width=max(1,int(w*Z)),joint='curve')
        for p in(P[0],P[-1]):s.d.ellipse([p[0]-w*Z/2,p[1]-w*Z/2,p[0]+w*Z/2,p[1]+w*Z/2],fill=f)
    def t(s,x,y,txt,f,sz,a='la'):s.d.text((x*Z,y*Z),txt,fill=f,font=fnt(int(sz*Z)),anchor=a)
def pad(D,x,y,w,h):
    if PADS:D.r(x,y,w,h,GOLD,1);D.r(x+.5,y+.5,w-1,h*.4,mix(GOLD,(255,255,255),.35),1)
def qpins(x,y,w,h):
    P=[]
    for i in range(int(w//9)-1):px=x+6+i*9+2.2;P+=[(px,y-9,0,-1),(px,y+h+9,0,1)]
    for i in range(int(h//9)-1):py=y+6+i*9+2.2;P+=[(x-9,py,-1,0),(x+w+9,py,1,0)]
    return P
def qfp(D,x,y,w,h,lab):
    for i in range(int(w//9)-1):
        px=x+6+i*9
        for py,o in((y-9,0),(y+h,1)):pad(D,px,py,4.5,9);D.r(px+.4,py+(1.5 if o==0 else .5),3.7,7,SILV,.5)
    for i in range(int(h//9)-1):
        py=y+6+i*9
        for px,o in((x-9,0),(x+w,1)):pad(D,px,py,9,4.5);D.r(px+(1.5 if o==0 else .5),py+.4,7,3.7,SILV,.5)
    D.r(x,y,w,h,(22,24,28),3,(58,61,68),1.2);D.r(x+3,y+3,w-6,h-6,(29,31,36),2);D.c(x+9,y+9,3,(78,82,90))
    D.t(x+w/2,y+h/2-5,lab[0],(150,154,160),11,'mm');D.t(x+w/2,y+h/2+9,lab[1],(105,109,116),9,'mm')
def soic(D,x,y,w,h,lab):
    for i in range(int(h//11)-1):
        py=y+6+i*11
        for px,o in((x-8,0),(x+w,1)):pad(D,px,py,8,5);D.r(px+(1.2 if o==0 else .4),py+.5,6.4,4,SILV,.5)
    D.r(x,y,w,h,(24,26,30),2.5,(58,61,68),1);D.c(x+7,y+7,2.5,(85,88,96));D.t(x+w/2,y+h/2,lab,(140,144,150),9,'mm')
def sm(D,x,y,w,h,k):
    e=6
    if w>h:D.r(x-3,y-1.5,e+3,h+3,GOLD,1);D.r(x+w-e,y-1.5,e+3,h+3,GOLD,1)
    else:D.r(x-1.5,y-3,w+3,e+3,GOLD,1);D.r(x-1.5,y+h-e,w+3,e+3,GOLD,1)
    D.r(x,y,w,h,(26,26,28) if k=='r' else (168,132,88),1.5)
    if w>h:D.r(x,y,4,h,SILV,1);D.r(x+w-4,y,4,h,SILV,1)
    else:D.r(x,y,w,4,SILV,1);D.r(x,y+h-4,w,4,SILV,1)
def hdr(D,x,y,n):
    D.r(x,y,16,n*12+6,(20,20,22),2,(60,60,64),1)
    for i in range(n):D.r(x+5,y+5+i*12,6,6,GOLD,1)
def elec(D,x,y,r):
    D.c(x,y,r+1.5,(20,20,22));D.c(x,y,r,(188,192,198));D.c(x,y,r*.78,(168,172,178));D.c(x-r*.2,y-r*.2,r*.35,(214,217,222))
    D.d.pieslice([(x-r)*Z,(y-r)*Z,(x+r)*Z,(y+r)*Z],-55,55,fill=(40,42,48));D.t(x+r*.6,y,'-',(220,220,220),12,'mm')
def xtal(D,x,y,w,h):
    D.r(x-2,y-2,w+4,h+4,GOLD,2);D.r(x,y,w,h,(196,200,206),4,(150,154,160),1);D.r(x+3,y+3,w-6,h*.3,(226,229,233),3);D.t(x+w/2,y+h/2+2,'16.000',(90,94,100),8,'mm')
def tr(D,x,y,dx,dy,g,B,lt,dk,w=4.4,n=3):
    pts=[(x,y)]
    for _ in range(n):
        L=g.randint(22,80);x+=dx*L;y+=dy*L
        if not(B[0]<x<B[2] and B[1]<y<B[3]):break
        pts.append((x,y));j=g.choice([-1,1]);ex,ey=(dx,j) if dx else (j,dy);l2=g.randint(12,32);x+=ex*l2;y+=ey*l2
        if not(B[0]<x<B[2] and B[1]<y<B[3]):break
        pts.append((x,y))
    if len(pts)<2:return
    D.l(pts,dk,w+2.6);D.l(pts,lt,w);ex,ey=pts[-1];D.c(ex,ey,w*1.5,dk);D.c(ex,ey,w*1.1,GOLD);D.c(ex,ey,w*.45,dk)
def ov(a,b):return a[0]<b[0]+b[2] and b[0]<a[0]+a[2] and a[1]<b[1]+b[3] and b[1]<a[1]+a[3]
def deco(D,bw,bh):
    for x,y in((24,24),(bw-24,24),(24,bh-24),(bw-24,bh-24)):D.c(x,y,11,GOLD);D.c(x,y,7,(70,76,72))
    D.t(40,bh-30,'MEGHA CIRCUITS  REV A  2026',WH,11)
def f_asm(D,g,c1,c2,bw,bh,multi=False):
    dk=mix(c2,(0,0,0),.45);lt=mix(c1,(255,255,255),.3);B=(14,14,bw-14,bh-14)
    for _ in range(26):tr(D,g.randint(30,bw-30),g.randint(30,bh-30),*g.choice(DIRS),g,B,lt,dk)
    cells=[(30+i*240,30+j*225) for j in range(2) for i in range(3)];g.shuffle(cells)
    roles=['bga','qfp','qfp','soic','mix','mix'] if multi else ['qfp','bga','soic','soic','mix','mix'];boxes=[];n=0
    for (ox,oy),ro in zip(cells,roles):
        cx,cy=ox+115,oy+105;n+=1
        if ro=='qfp':
            w,h=g.choice([(100,90),(110,100)]);x,y=cx-w/2,cy-h/2
            for p in qpins(x,y,w,h):tr(D,p[0],p[1],p[2],p[3],g,B,lt,dk,3.4,2)
            qfp(D,x,y,w,h,(g.choice(['STM32','ATMEGA','ESP32','PIC18','LPC11']),str(g.randint(1000,9999))));D.t(x-6,y-24,'U%d'%n,WH,10);boxes.append((x-26,y-26,w+52,h+52))
        elif ro=='bga':
            s=130 if multi else 94;x,y=cx-s/2,cy-s/2
            for i in range(9):
                t=x+8+i*(s-16)/8;u=y+8+i*(s-16)/8
                tr(D,t,y,0,-1,g,B,lt,dk,3.2,2);tr(D,t,y+s,0,1,g,B,lt,dk,3.2,2);tr(D,x,u,-1,0,g,B,lt,dk,3.2,2);tr(D,x+s,u,1,0,g,B,lt,dk,3.2,2)
            if multi:
                for i in range(0,int(s+36),12):
                    for vx,vy in((x-18+i,y-18),(x-18+i,y+s+18),(x-18,y-18+i),(x+s+18,y-18+i)):D.c(vx,vy,3.4,GOLD);D.c(vx,vy,1.4,dk)
            D.r(x,y,s,s,(26,28,33),4,(62,66,74),1.4);D.r(x+4,y+4,s-8,s-8,(32,34,40),3);D.c(x+10,y+10,3,(80,84,92))
            D.t(x+s/2,y+s/2-5,g.choice(['XC7A35T','AM3358','i.MX6','RK3288']),(150,154,160),11,'mm');D.t(x+s/2,y+s/2+9,'BGA-%d'%g.choice([256,324,400]),(105,109,116),9,'mm');boxes.append((x-26,y-26,s+52,s+52))
        elif ro=='soic':
            w,h=44,66;x,y=cx-w/2,cy-h/2
            for i in range(int(h//11)-1):
                py=y+6+i*11+2.5;tr(D,x-8,py,-1,0,g,B,lt,dk,3.2,2);tr(D,x+w+8,py,1,0,g,B,lt,dk,3.2,2)
            soic(D,x,y,w,h,g.choice(['LM358','74HC595','MAX232','NE555']));boxes.append((x-24,y-8,w+48,h+16))
        else:
            xtal(D,ox+30,oy+30,48,20);hdr(D,ox+150,oy+24,6);elec(D,ox+70,oy+130,24);elec(D,ox+150,oy+150,18)
            boxes+=[(ox+20,oy+20,70,40),(ox+140,oy+14,36,90),(ox+40,oy+96,60,64),(ox+126,oy+126,48,48)]
    for ox,oy in cells:
        for _ in range(6):
            for _t in range(25):
                w,h=g.choice([(20,10),(10,20),(20,10)]);x=ox+g.randint(0,210);y=oy+g.randint(0,195);bb=(x-8,y-8,w+16,h+16)
                if not any(ov(bb,b) for b in boxes):
                    boxes.append(bb);sm(D,x,y,w,h,g.choice('rc'))
                    if g.random()<.35:D.t(x,y+h+3,g.choice('RC')+str(g.randint(1,40)),WH,8)
                    break
def f_single(D,g,c1,c2,bw,bh):
    dk=mix(c2,(0,0,0),.45);lt=mix(c1,(255,255,255),.3);B=(14,14,bw-14,bh-14)
    def pd(x,y,r=8):D.c(x,y,r+2.5,dk);D.c(x,y,r,SILV);D.c(x,y,r*.5,(36,42,38))
    for _ in range(16):tr(D,g.randint(40,bw-40),g.randint(40,bh-40),*g.choice(DIRS),g,B,lt,dk,8,3)
    cols=[(120,60,20),(30,30,30),(200,40,30),(230,150,30),(40,80,200),(60,150,60),(150,40,160),(200,200,200)]
    for i in range(6):
        y=62+i*72;x=g.randint(40,230);tr(D,x,y,-1,0,g,B,lt,dk,8,2);tr(D,x+74,y,1,0,g,B,lt,dk,8,2);pd(x,y);pd(x+74,y)
        D.l([(x+4,y),(x+70,y)],SILV,3);D.r(x+16,y-8,42,16,(224,203,150),7,(180,160,110),1.2)
        for b in range(4):D.r(x+22+b*8+(4 if b==3 else 0),y-8,4,16,cols[g.randrange(8)],0)
        D.t(x+37,y+22,'R%d'%(i+1),WH,10,'mm')
    for i in range(3):
        cx,cy=480+i*90,120+g.randint(-10,10);tr(D,cx-8,cy+36,0,1,g,B,lt,dk,8,2);tr(D,cx+8,cy+36,0,1,g,B,lt,dk,8,2);pd(cx-8,cy+36,7);pd(cx+8,cy+36,7);elec(D,cx,cy,26)
    x,y=350,190
    for i in range(7):
        py=y+12+i*15;tr(D,x-12,py,-1,0,g,B,lt,dk,6,2);tr(D,x+74,py,1,0,g,B,lt,dk,6,2);pd(x-12,py,6);pd(x+74,py,6)
    D.r(x,y,62,118,(24,26,30),3,(58,61,68),1.2);D.c(x+31,y,8,(40,42,48));D.t(x+31,y+60,'NE555',(140,144,150),11,'mm')
    D.r(486,410,200,40,(20,20,22),3)
    for i in range(6):pd(502+i*34,430,9)
def f_metal(D,g,c1,c2,bw,bh):
    dark=sum(c1)<330;cu=(198,152,100);cd=(120,86,52)
    R=g.choice([2,3,3,4]);C=g.choice([4,5,5,6]);span={2:190,3:270,4:300}[R];y0=(bh-span)/2-4;dy=span/(R-1);x0=150;dx=(bw-300)/(C-1);seq=[]
    LED=g.choice([((252,212,64),(255,240,170)),((236,244,255),(255,255,255)),((244,84,70),(255,176,150)),((92,224,128),(196,255,206))])
    for j in range(R):
        row=[(x0+i*dx,y0+j*dy) for i in range(C)];seq+=row if j%2==0 else row[::-1]
    ye=y0+(R-1)*dy;ex=bw-50 if R%2 else 50;pts=[(50,y0)]+seq+[(ex,ye)];D.l(pts,cd,12);D.l(pts,cu,8)
    for x,y in seq:
        D.r(x-14,y-14,28,28,(236,236,230),4,(170,170,165),1.4);D.c(x,y,9.5,LED[0]);D.c(x,y,5.5,LED[1]);D.r(x-18,y-6,6,12,GOLD,1);D.r(x+12,y-6,6,12,GOLD,1)
    D.r(26,y0-26,48,52,GOLD,5);D.r(bw-74 if R%2 else 26,ye-26,48,52,GOLD,5)
    for x,y in((30,250),(bw-30,250)):D.c(x,y,12,(150,155,160));D.c(x,y,8,(80,84,88))
    D.t(bw/2,bh-30,'MEGHA CIRCUITS  ALUMINIUM LED BOARD',(176,180,186) if dark else (110,114,120),12,'mm')
def f_flex(D,g,c1,c2,bw,bh):
    dark=sum(c1)<330;cu=(244,204,110) if dark else (240,196,98);cd=(110,70,20) if dark else (146,88,16);d=g.choice([-40,-26,0,26,40]);n=g.choice([7,8,9,10]);sp=g.choice([20,22,24]);npad=g.choice([8,10,12,14])
    for x in(0,bw-86):D.r(x+6,30,80,bh-60,(224,206,148),5,(170,150,96),1.6)
    for k in range(n):
        y=(bh-(n-1)*sp)/2+k*sp;pts=[(30,y),(250,y),(300,y+d),(bw-300,y+d),(bw-250,y),(bw-30,y)];D.l(pts,cd,8.5);D.l(pts,cu,5.5)
    for k in range(npad):
        y=48+k*(bh-96)/(npad-1);D.r(10,y-4,46,8,GOLD,1);D.r(bw-56,y-4,46,8,GOLD,1)
    kind=g.choice(['ic','ic','duo'])
    if kind=='ic':
        D.r(bw/2-40,bh/2-22+d/2,80,44,(24,26,30),3,(60,62,68),1.2)
        for i in range(8):D.r(bw/2-34+i*9,bh/2+22+d/2,5,8,SILV,.5)
    else:
        for ox in(-70,10):
            D.r(bw/2+ox,bh/2-18+d/2,60,36,(24,26,30),3,(60,62,68),1.2);D.c(bw/2+ox+9,bh/2-9+d/2,3,(85,88,96))
            for i in range(5):D.r(bw/2+ox+6+i*10,bh/2+18+d/2,5,7,SILV,.5)
    D.t(bw/2,bh-26,'FLEX-%02d  MEGHA CIRCUITS'%g.randint(1,40),(214,180,120) if dark else (120,70,12),12,'mm')
def f_stencil(D,g,c1,c2,bw,bh):
    ap=(34,38,44);ed=(210,214,220)
    def sq(x,y,w,h):D.r(x-.8,y-.8,w+1.6,h+1.6,ed,1);D.r(x,y,w,h,ap,.8)
    cells=[(30+i*240,40+j*230) for j in range(2) for i in range(3)];g.shuffle(cells)
    for k,(ox,oy) in enumerate(cells):
        cx,cy=ox+115,oy+100
        if k%3==0:
            for i in range(10):sq(cx-44+i*9,cy-57,4,10);sq(cx-44+i*9,cy+47,4,10)
            for i in range(9):sq(cx-62,cy-39+i*9,10,4);sq(cx+52,cy-39+i*9,10,4)
            sq(cx-30,cy-30,60,60)
        elif k%3==1:
            for i in range(10):
                for j in range(10):D.c(cx-45+i*10,cy-45+j*10,3.4,ed);D.c(cx-45+i*10,cy-45+j*10,2.7,ap)
        else:
            for i in range(14):sq(ox+10+(i%7)*30,oy+20+(i//7)*40,12,10);sq(ox+26+(i%7)*30,oy+20+(i//7)*40,12,10)
            for i in range(6):sq(ox+20+i*34,oy+140,10,24)
    for x,y in((26,26),(bw-26,26),(26,bh-26),(bw-26,bh-26)):D.c(x,y,13,(60,66,72));D.c(x,y,10,ap)
    for x,y in((70,70),(bw-70,bh-70)):D.c(x,y,8,mix(c1,(255,255,255),.4));D.c(x,y,4,c2)
    D.t(bw/2,bh-22,'MEGHA CIRCUITS  STENCIL 0.12 MM',(70,76,84),12,'mm')
def f_design(D,g,c1,c2,bw,bh):
    gc=(24,42,78);bg=(8,16,36)
    for x in range(0,bw,25):D.l([(x,0),(x,bh)],gc,.8)
    for y in range(0,bh,25):D.l([(0,y),(bw,y)],gc,.8)
    D.r(34,34,bw-68,bh-68,None,6,(240,222,96),2.2);B=(50,50,bw-50,bh-50)
    for col in((235,72,72),(72,138,242)):
        for _ in range(26):tr(D,g.randint(60,bw-60),g.randint(60,bh-60),*g.choice(DIRS),g,B,col,bg,4,3)
    for i in range(3):
        for j in range(2):
            ox,oy=30+i*240,30+j*225;w,h=g.randint(60,120),g.randint(50,100);x,y=ox+g.randint(10,100),oy+g.randint(10,90)
            D.r(x,y,w,h,bg,2,(84,222,232),1.8)
            for k in range(int(w//12)):D.r(x+4+k*12,y-5,6,8,(80,226,128));D.r(x+4+k*12,y+h-3,6,8,(80,226,128))
            D.t(x+w/2,y+h/2,'U%d'%g.randint(1,30),(240,244,250),11,'mm')
    D.t(44,bh-26,'MEGHA CIRCUITS  PCB LAYOUT   TOP RED   BOTTOM BLUE',(170,200,240),10)
def f_panel(D,g,c1,c2,bw,bh):
    dk=mix(c2,(0,0,0),.45);lt=mix(c1,(255,255,255),.3);sd=g.randrange(10**6);ib=mix(c1,(0,0,0),.14)
    for j in range(2):
        for i in range(3):
            x,y,w,h=45+i*230,60+j*215,210,190;D.r(x,y,w,h,ib,6,dk,2.2);r=random.Random(sd);B=(x+8,y+8,x+w-8,y+h-8)
            for _ in range(14):tr(D,r.randint(x+30,x+w-30),r.randint(y+30,y+h-30),*r.choice(DIRS),r,B,lt,dk,3.4,2)
            for k in range(8):pad(D,x+22+k*22,y+12,10,16);pad(D,x+22+k*22,y+h-28,10,16)
            D.t(x+w/2,y+h/2,'MC-%d'%(sd%90+10),WH,13,'mm')
            for _ in range(8):D.c(r.randint(x+20,x+w-20),r.randint(y+40,y+h-40),3.5,GOLD)
    for x,y in((22,22),(bw-22,22),(22,bh-22),(bw-22,bh-22)):D.c(x,y,8,GOLD);D.c(x,y,5,(70,76,72))
    D.t(bw/2,bh-26,'MEGHA CIRCUITS  PANEL 3 X 2',WH,12,'mm')
FN={'assembly':f_asm,'single':f_single,'multi':lambda *a:f_asm(*a,True),'metal':f_metal,'flex':f_flex,'stencil':f_stencil,'design':f_design,'panel':f_panel}
def base(bw,bh,c1,c2,rad,g):
    im=Image.new('RGBA',(bw*Z,bh*Z),(0,0,0,0));m=Image.new('L',im.size,0);ImageDraw.Draw(m).rounded_rectangle([0,0,bw*Z-1,bh*Z-1],radius=rad*Z,fill=255)
    im.paste(grad(bw*Z,bh*Z,c1,c2,3,g.randrange(99)).convert('RGBA'),(0,0),m);return im,m
def flat(st,g,pal):
    c1,c2=pal;bw,bh=(760,320) if st=='flex' else (750,520) if st in('stencil','panel') else (750,500)
    c1,c2={'flex':g.choice([((226,152,42),(184,110,22)),((226,152,42),(184,110,22)),((58,50,46),(32,28,26))]),'metal':g.choice([((238,240,242),(208,212,217)),((214,218,224),(176,181,189)),((46,48,54),(22,24,28))]),'stencil':((188,193,199),(122,129,137)),'design':((12,24,50),(8,16,36)),'multi':((30,60,120),(14,30,76))}.get(st,(c1,c2))
    im,m=base(bw,bh,c1,c2,10 if st=='stencil' else 18,g)
    if st=='stencil':
        a=np.array(im.convert('RGB')).astype(float)+np.random.default_rng(7).normal(0,6,(im.height,1,1));im=Image.fromarray(np.clip(a,0,255).astype('uint8')).convert('RGBA')
    D=Dw(im);FN[st](D,g,c1,c2,bw,bh)
    if st in('assembly','single','multi'):deco(D,bw,bh)
    im.putalpha(m);return im
def coeffs(dst,src):
    A=[];b=[]
    for (x,y),(u,v) in zip(dst,src):A+=[[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]];b+=[u,v]
    return np.linalg.solve(np.array(A,float),np.array(b,float)).tolist()
def warp(fl,g):
    w,h=fl.size;sc=min(2000/w,1300/h)*.96;tw,th=w*sc,h*sc;cx,cy=CW/2,CH/2;j=lambda a:g.randint(-a,a)
    q=[(cx-tw/2+j(60),cy-th/2+j(40)),(cx+tw/2+j(60),cy-th/2+j(40)),(cx+tw/2+j(60),cy+th/2+j(40)),(cx-tw/2+j(60),cy+th/2+j(40))]
    return fl.transform((CW,CH),Image.PERSPECTIVE,coeffs(q,[(0,0),(w,0),(w,h),(0,h)]),Image.BICUBIC)
def shadow(lay,a,bl,off,op):
    sh=Image.new('RGBA',lay.size,(0,0,0,255));sh.putalpha(a.filter(ImageFilter.GaussianBlur(bl)).point(lambda v:int(v*op)));return sh
def L_stack(g,k):
    lay=Image.new('RGBA',(CW,CH),(0,0,0,0))
    for idx,(pal,ang,cx,cy) in enumerate([(PAL[2],-9,760,830),(PAL[3],7,1500,650),(PAL[0],-3,1150,880)]):
        fl=flat('assembly',random.Random(k+str(idx)),pal);fl=fl.resize((int(fl.width*.72),int(fl.height*.72)),Image.LANCZOS).rotate(ang,Image.BICUBIC,expand=True)
        pos=(int(cx-fl.width/2),int(cy-fl.height/2));msk=Image.new('L',lay.size,0);msk.paste(fl.split()[3],pos)
        lay.alpha_composite(shadow(lay,msk,22,0,.6),(18,30));lay.alpha_composite(fl,pos)
    return lay
def L_chips(g):
    global PADS;PADS=False;lay=Image.new('RGBA',(CW,CH),(0,0,0,0))
    for j in range(2):
        for i in range(4):
            kd=g.choice(['qfp','qfp','soic','bga','soic']);w,h={'qfp':(100,100),'soic':(50,76),'bga':(110,110)}[kd]
            tmp=Image.new('RGBA',((w+60)*Z,(h+60)*Z),(0,0,0,0));T=Dw(tmp);x=y=30
            if kd=='qfp':qfp(T,x,y,w,h,(g.choice(['STM32','ATMEGA','ESP32','PIC18']),str(g.randint(1000,9999))))
            elif kd=='soic':soic(T,x,y,w,h,g.choice(['LM358','74HC595','MAX232']))
            else:T.r(x,y,w,h,(26,28,33),4,(62,66,74),1.4);T.c(x+10,y+10,3,(80,84,92));T.t(x+w/2,y+h/2-5,'XC7A35T',(150,154,160),11,'mm');T.t(x+w/2,y+h/2+9,'BGA-256',(105,109,116),9,'mm')
            tmp=tmp.rotate(g.uniform(-40,40),Image.BICUBIC,expand=True);tmp=tmp.resize((int(tmp.width*1.5),int(tmp.height*1.5)),Image.LANCZOS)
            cx=330+i*580+g.randint(-50,50);cy=430+j*650+g.randint(-50,50);lay.alpha_composite(tmp,(int(cx-tmp.width/2),int(cy-tmp.height/2)))
    PADS=True;return lay
def finish(lay,bgc,path):
    bg=grad(CW,CH,bgc[0],bgc[1],2.5,5).convert('RGBA');a=lay.split()[3]
    for bl,off,op in((34,(30,52),.5),(7,(8,14),.55)):bg.alpha_composite(shadow(lay,a,bl,off,op),off)
    bg.alpha_composite(lay);arr=np.array(bg.convert('RGB')).astype(np.float32);X=np.linspace(0,1,CW)[None,:];Y=np.linspace(0,1,CH)[:,None]
    arr*=(1.13-.26*(X*.55+Y*.45))[...,None];arr+=(np.exp(-((X*.5+Y*.5-.38)/.07)**2)*16)[...,None];arr*=(1-.5*((X-.5)**2+(Y-.5)**2))[...,None]
    arr+=np.random.default_rng(3).normal(0,2,arr.shape[:2])[...,None]
    Image.fromarray(np.clip(arr,0,255).astype('uint8')).resize((1000,667),Image.LANCZOS).save(path,'JPEG',quality=80,optimize=True)
def build(k,path):
    g=random.Random(k);st=next((s for s,ws in RULES if any(w in k for w in ws)),None) or g.choice(['assembly','assembly','multi','panel','single','design','metal'])
    pal=PAL[2] if 'turnkey' in k else PAL[4] if 'manufactur' in k else g.choice(PAL)
    for w_,p_ in FORCE:
        if w_ in k:pal=p_
    bgc=((214,221,216),(158,168,162))
    if st=='chips':lay=L_chips(g);bgc=((46,50,54),(18,20,22))
    elif st=='stack':lay=L_stack(g,k)
    else:lay=warp(flat(st,g,pal),g)
    finish(lay,bgc,path)
def make(k,path):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    if not os.path.exists(path) and (k,path) not in Qd:Qd.append((k,path))
def _job(a):build(*a)
def flush():
    if not Qd:return
    from multiprocessing import Pool,cpu_count
    with Pool(max(1,min(4,cpu_count()))) as p:p.map(_job,Qd,chunksize=1)
    Qd.clear()
